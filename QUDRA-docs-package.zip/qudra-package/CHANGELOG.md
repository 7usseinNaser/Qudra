# CHANGELOG.md — سجل التغييرات

> يُحدَّث بعد كل مهمة منجزة، بصيغة تشبه Conventional Commits حيثما أمكن.

---

## [Unreleased]

### docs
- **إنشاء حزمة التوثيق الموحدة الكاملة**: `README.md`, `قواعد.md`, `SKILLS.md`, `CLAUDE.md`/`AGENTS.md`, `.memory/` (glossary, decisions, notes), وتحديث `TASKS.md`, `STATUS.md`, `DECISIONS.md`, `CHANGELOG.md`, `TEST_REPORT.md`.
- توحيد جميع الملفات المبعثرة السابقة (01_فكرة، 02_قواعد، 03_TASKS، 04_BRD، README القديمة) في مصدر حقيقة واحد لكل موضوع.
- استخراج توكنز الألوان الفعلية من `prototype.html` (بدل الوصف التقريبي) وتوثيقها بدقة في `README.md` و`قواعد.md`.
- تصحيح خط الـ Display المعتمد إلى Readex Pro (حسب `design-system.html`) بدل IBM Plex Sans Arabic المذكور خطأً في نسخ قديمة من ملف القواعد.

---

## كيف تُضاف مهمة جديدة لهذا السجل

```markdown
## [YYYY-MM-DD]

### feat | fix | docs | refactor | style | test | chore
- وصف موجز وواضح للتغيير، بصيغة الفعل الحاضر (مثال: "إضافة مكوّن Tag بحالتي proven/claimed").
```
